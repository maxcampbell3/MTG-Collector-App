from django.db import models
from django.urls import reverse

from django.db.models import Q


 
 #add num of copies 

class card_in_collection(models.Model):
    # "name"
    name = models.TextField()
    # pulled from layout
    is_Flip = models.BooleanField(default = False, null= False)
    # pulled from card_faces if double sided left null if not 
    back_side_card_name = models.TextField(blank=True, null=True)
    # "mana_cost" is a string like 2ub 
    mana_cost = models.TextField(blank=True, null=True) 
    # "type_line" card type line 
    type_line = models.TextField(blank=True, null=True)
    #'cmc'
    cmc = models.TextField(blank=True, null=True)
    # pulled from image_uris.normal
    image_url = models.TextField(blank=True, null=True) 
    #not null only when is_flip is True 
    back_side_img_url = models.TextField(blank=True, null=True) 
    #pulled from oracle_text
    card_description = models.TextField(blank=True, null=True)
    #flavor
    flavor_text =  models.TextField(blank=True, null=True)

    color = models.TextField(blank=True, null=True)
    
    

    standard_legal = models.TextField(blank=True, null=True)
    historic_legal = models.TextField(blank=True, null=True)
    pioneer_legal = models.TextField(blank=True, null=True)
    modern_legal = models.TextField(blank=True, null=True)
    legacy_legal = models.TextField(blank=True, null=True)
    pauper_legal = models.TextField(blank=True, null=True)
    vintage_legal = models.TextField(blank=True, null=True)
    commander_legal = models.TextField(blank=True, null=True)

    #is_a_viable_commander = models.BooleanField(default = False, null= False)
    def __str__(self):
        return self.name

    class Meta:
        ordering = ['cmc']
        verbose_name = ("card_in_collection")
        verbose_name_plural = ("cards_in_collection")

    def get_absolute_url(self):
        return reverse('card-detail', kwargs={
            'pk': self.pk
        })
    

class deck(models.Model):
    name = models.TextField()
    commander = models.ForeignKey(
        card_in_collection, 
        on_delete=models.CASCADE, 
        related_name="commander", 
        blank=True, 
        null=True, 
        limit_choices_to= Q(type_line__icontains ="Legendary Creature")| Q(card_description__icontains ="can be your commander") & Q(commander_legal = 'legal')
        )
    mtg_format = models.TextField()
    colors = models.TextField(blank=True, null=True)
    Tot_price = models.FloatField(blank=True, null=True)
    Avg_cmc = models.FloatField(blank=True, null=True)
    Basic_Land_count = models.IntegerField(blank=True, null=True)
    Land_count = models.IntegerField(blank=True, null=True)
    num_of_swamp = models.PositiveIntegerField(blank=True, null=True, default = 0) 
    num_of_plain = models.PositiveIntegerField(blank=True, null=True, default = 0)
    num_of_forest = models.PositiveIntegerField(blank=True, null=True, default = 0)
    num_of_island = models.PositiveIntegerField(blank=True, null=True, default = 0)
    num_of_mountain = models.PositiveIntegerField(blank=True, null=True, default = 0)
    cards = models.ManyToManyField(card_in_collection, related_name= "cards_in_deck", blank=True)
    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('deck-detail', args=[str(self.id)])


#limit_choices_to={models.Q(type_line__icontains ='Legendary Creature') or models.Q(card_description__icontains ='can be your commander')}