from django.shortcuts import render, get_object_or_404,redirect,HttpResponse
from django.views import generic
from django.views.generic import UpdateView
from django.views.generic.detail import DetailView
from django.core.files.base import ContentFile
from django.views.generic.edit import FormMixin
from django.db.models import Q
from django import forms
from .models import card_in_collection,deck
from .forms import CardSearchForm,CreateDeckForm,DeckImportForm
import requests,urllib,json,time 
from django.views.decorators.csrf import csrf_exempt,csrf_protect


limit_exceptions = [
    "Persistent Petitioners",
    "persistent petitioners",
    "Rat Colony",
    "rat colony",
    "Relentless Rats",
    "relentless rats",
    "Shadowborn Apostle",
    "shadowborn apostle",
    ]

class SearchView(generic.View):
    form_class = CardSearchForm
    initial = {'key': 'value'} # change
    template_name = 'collection/add_card.html'

    
    def get(self, request,*args, **kwargs):
        form = self.form_class(initial=self.initial)
        context = { 
            'form' : form
        }
       
        return render(request,'collection/add_card.html',context)
    
   
    def post(self, request,*args, **kwargs):
        
        form = CardSearchForm(request.POST)
        context = {
            # that list of dictionaries 
            'form' : form
        }
       
        #values for creating the api call 
        if form.is_valid():
            #form data 
            params = {
                'name:': form.cleaned_data['card_name'],
                'cmc=': form.cleaned_data['cmc'],
                't:' : form.cleaned_data['Card_Type'],
                'c:' : form.cleaned_data['Color']
                }
            
            #form = CardSearchForm()

            for key in list(params):
                if params.get(key) == None or params.get(key) == '':
                    del params[key] 

            
            call_str =''
            #creating scryfall api call 
            i=0 
            for key, value in params.items():
                i +=1
                call_str += str(key) 
                call_str += str(value) 
                if i != len(params)-1: 
                    call_str += ' '

            call_dict= {
                'q' : call_str
            }
            call = 'https://api.scryfall.com/cards/search?' + urllib.parse.urlencode(call_dict) 
            
            
            results_list= requests.get(call).json()
            #add check for returned error 
            if results_list.get('object') == 'error':
                
                context = {
                    'form' : form,
                    'error' : "Nothing was Found"
                }
                return render(request,'collection/add_card.html', context)

            #valid search
            if results_list.get('object') == 'list':
                
                card_dict= {} 
                parse_list= {}
                #grab first page 
                parse_list = results_list.get('data')
                #loop to check for addtional pages 
                while results_list.get('has_more') == True :
                    time.sleep(.1)
                    results_list=requests.get(results_list.get("next_page")).json()
                    parse_list.extend(results_list.get('data'))

                
                for result in parse_list:
                    
                    if result.get('layout') == 'modal_dfc' or result.get('layout') == "transform" : 
                        
                        temp_str=result.get('id')
                        card_dict[temp_str] = result.get('card_faces')[0]
                        
                    else:
                        temp_str=result.get('id')
                        card_dict[temp_str] = result
                
                        
                context['card_dict'] = card_dict
                  
                return render(request,'collection/add_card.html', context)
       
        #send the result list of dictionaries to template 
        return render(request,'collection/add_card.html', context)

class add_card_view(generic.View):
    
    
    def post(self, request,*args, **kwargs):
        
        if len(request.POST) == 3:
            add_card_name = list(request.POST)[2]
            add_card_name = add_card_name[:-2]
            card_to_be_added = requests.get("https://api.scryfall.com/cards/named?exact=" + add_card_name).json()
       
            if card_to_be_added.get("layout")  == 'modal_dfc' or card_to_be_added.get('layout') == "transform" :
                context = {
                    'card' : card_to_be_added.get("card_faces")[0]
                }
              
            else:
                context = {
                    'card' : card_to_be_added
                }
            if card_in_collection.objects.filter(name = card_to_be_added.get("name")):
                context['dupe'] = "This card is already in your collection would you like to add another copy?"  
               
            return render(request, 'collection/add_card_confirm.html', context)
        
        else:
            add_card_name = list(request.POST)[1]
            card_to_be_added = requests.get("https://api.scryfall.com/cards/named?exact=" + add_card_name).json()
            context ={

            }
            #creates the card and grabs the appropriate data 
            # location of data in JSON dict can change depending on the card type 
            if card_to_be_added.get("layout") == "split" or card_to_be_added.get("layout") == "flip":
                front_face = card_to_be_added.get("card_faces")[0]
                back_face = card_to_be_added.get("card_faces")[1]
                card_in_collection.objects.create(
                    name = card_to_be_added.get('name'),
                    is_Flip = True,
                    back_side_card_name = back_face.get("name"),        
                    mana_cost = card_to_be_added.get("mana_cost"),
                    type_line = card_to_be_added.get("type_line"),
                    cmc = card_to_be_added.get("cmc"),
                    image_url = card_to_be_added.get("image_uris").get("border_crop"),
                    back_side_img_url = '',
                    card_description = front_face.get("oracle_text") + "//" + back_face.get("oracle_text"),
                    flavor_text = front_face.get("flavor_text"),
                    color = card_to_be_added.get("color_identity"),
                    standard_legal = card_to_be_added.get("legalities").get("standard"),
                    historic_legal = card_to_be_added.get("legalities").get("historic"),
                    pioneer_legal = card_to_be_added.get("legalities").get("pioneer"),
                    modern_legal = card_to_be_added.get("legalities").get("modern"),
                    legacy_legal = card_to_be_added.get("legalities").get("legacy"),
                    pauper_legal = card_to_be_added.get("legalities").get("pauper"),
                    vintage_legal = card_to_be_added.get("legalities").get("vintage"),
                    commander_legal = card_to_be_added.get("legalities").get("commander"),
                    

                )

            elif card_to_be_added.get("layout")  == 'modal_dfc' or card_to_be_added.get('layout') == "transform" :
                front_face = card_to_be_added.get("card_faces")[0]
                back_face = card_to_be_added.get("card_faces")[1]

                card_in_collection.objects.create(
                    name = card_to_be_added.get('name'),
                    is_Flip = True,
                    back_side_card_name = back_face.get("name"),        
                    mana_cost = card_to_be_added.get("mana_cost"),
                    type_line = card_to_be_added.get("type_line"),
                    cmc = card_to_be_added.get("cmc"),
                    image_url = front_face.get("image_uris").get("border_crop"),
                    back_side_img_url = back_face.get("image_uris").get("border_crop"),
                    card_description = front_face.get("oracle_text") + "//" + back_face.get("oracle_text"),
                    flavor_text = front_face.get("flavor_text"),
                    color = card_to_be_added.get("color_identity"),
                    standard_legal = card_to_be_added.get("legalities").get("standard"),
                    historic_legal = card_to_be_added.get("legalities").get("historic"),
                    pioneer_legal = card_to_be_added.get("legalities").get("pioneer"),
                    modern_legal = card_to_be_added.get("legalities").get("modern"),
                    legacy_legal = card_to_be_added.get("legalities").get("legacy"),
                    pauper_legal = card_to_be_added.get("legalities").get("pauper"),
                    vintage_legal = card_to_be_added.get("legalities").get("vintage"),
                    commander_legal = card_to_be_added.get("legalities").get("commander"),
                    

                )
        
            else:

                card_in_collection.objects.create(
                    name = card_to_be_added.get('name'),
                    is_Flip = False,
                    back_side_card_name = '',    
                    mana_cost = card_to_be_added.get("mana_cost"),
                    type_line = card_to_be_added.get("type_line"),
                    cmc = card_to_be_added.get("cmc"),
                    image_url = card_to_be_added.get("image_uris").get("border_crop"),
                    back_side_img_url = '',
                    card_description = card_to_be_added.get("oracle_text"),
                    flavor_text = card_to_be_added.get("flavor_text"),
                    color = card_to_be_added.get("color_identity"),
                    standard_legal = card_to_be_added.get("legalities").get("standard"),
                    historic_legal = card_to_be_added.get("legalities").get("historic"),
                    pioneer_legal = card_to_be_added.get("legalities").get("pioneer"),
                    modern_legal = card_to_be_added.get("legalities").get("modern"),
                    legacy_legal = card_to_be_added.get("legalities").get("legacy"),
                    pauper_legal = card_to_be_added.get("legalities").get("pauper"),
                    vintage_legal = card_to_be_added.get("legalities").get("vintage"),
                    commander_legal = card_to_be_added.get("legalities").get("commander"),
                    
                )

            
            return redirect('/')

class CollectionView(generic.ListView):
    model = card_in_collection
    template_name ='collection/home.html'
    
    def get_queryset(self, *args, **kwargs):
        name = self.kwargs.get('id','')
       
        order = self.request.GET.get('id', 'id')
        return card_in_collection.objects.all().order_by(order)

    def get_context_data(self, **kwargs):
        context = super(CollectionView, self).get_context_data(**kwargs)
        context['orderby'] = self.request.GET.get('orderby', 'id')
        return context

class SearchCollectionView(generic.ListView):
    model = card_in_collection
    template_name ='collection/home.html'

    def get_queryset(self, *args, **kwargs):
        queryset = card_in_collection.objects.none()
        name = self.request.GET.get('name',"")
        cmc = self.request.GET.get('cmc',"")
        color = self.request.GET.get('color',"")
        cardType = self.request.GET.get('cardtype',"")
        color_list =""
        
        if "White" in color or "white" in color:
            color_list += 'W'
        if "Blue" in color or "blue" in color:
            color_list +='U'
        if "Black" in color or "black" in color:
            color_list += 'B'
        if "Red" in color or "red" in color:
            color_list += 'R'
        if "Green" in color or "green" in color:
            color_list += 'G'
        
        
        if color_list:
            for color in color_list:
                queryset = queryset | card_in_collection.objects.filter(color__icontains = color)
            if name:
                queryset = queryset.filter(name__icontains=name)
            if cmc != '':
                queryset = queryset.filter(cmc__icontains=cmc)
            if cardType:
                queryset = queryset.filter(type_line__icontains=cardType)
        else:    
            queryset = card_in_collection.objects.all()        
            if name:
                queryset = queryset.filter(name__icontains=name)
            if cmc != '':
                queryset = queryset.filter(cmc__icontains=cmc)
            if cardType:
                queryset = queryset.filter(type_line__icontains=cardType)
            
        
        return queryset

class DeckListView(generic.ListView):
    model = deck
    template_name ='collection/my_decks.html'
    
    def get_queryset(self):
        return deck.objects.all()

class DeckDetailView(DetailView):
    model = deck 
    template_name = 'collection/deck_detail.html'
    queryset = deck.objects.all()

    def get_object(self):
        
        context = super().get_object()
        return context

class CardDetailView(DetailView):
    model = card_in_collection
    template_name = 'collection/card_detail.html'
    queryset = card_in_collection.objects.all()
    def get_object(self):
        
        num_of_copies =0
        context=super().get_object()
       
        return context

    def get_context_data(self, **kwargs):
        name = super().get_object().name
        #pulls card data from api due to changing nature of this data field 
        card = requests.get("https://api.scryfall.com/cards/named?exact=" + name).json()
        context = super().get_context_data(**kwargs)
        if card.get("prices").get("usd"):
            context['price'] = float(card.get("prices").get("usd"))
        else:
            context['price'] =  float(card.get("prices").get("usd_foil"))
        
        return context

class CardDeleteView(generic.DeleteView):
    model = card_in_collection
    success_url = '/'
    
class DeckCreateView(generic.View):
    form_class = CreateDeckForm
    template_name = 'collection/create_deck.html'
    initial = {} # change
    
    def get(self, request,*args, **kwargs):
        form = self.form_class(initial=self.initial)
        context = { 
            'form' : form
        }
        
        return render(request,'collection/create_deck.html',context)
    
    def post(self, request,*args, **kwargs):
        
        avg_cmc = 0.0
        tot_cmc = 0.0
        total_cost = 0.0
        total_lands = 0
        form = CreateDeckForm(request.POST)
        context={
            'form' : form
        }
        if form.is_valid():   
        
            num_of_lands_in_list = 0
            num_of_nonlands = 0.0
            num_of_basic_lands = 0
            
            deck_list = form.cleaned_data['cards']
            deck_commander = form.cleaned_data['commander']
            deck_colors = ''
            num_of_forest  = form.cleaned_data['num_of_forest']
            num_of_island  = form.cleaned_data['num_of_island']
            num_of_mountain  = form.cleaned_data['num_of_mountain']
            num_of_plain = form.cleaned_data['num_of_plain']
            num_of_swamp  = form.cleaned_data['num_of_swamp']

            #ignores basics outside of colors 
            

            #adds commander card stats to running totals 
           
           #checks the number of copies of each card
            for card in deck_list:
                if form.cleaned_data['mtg_format'] != "Commander":
                    if deck_list.filter(name = card.name).count() > 4 and card.name not in limit_exceptions:
                        context={
                            'form' : CreateDeckForm(request.POST),
                            'invalidQuantity' :"A Deck can only have 4 copies of most cards"
                        }
                        
                        return render(request,'collection/create_deck.html',context)
                else:
                    if deck_list.filter(name= card.name).count() > 1 and card.name not in limit_exceptions:
                        context={
                            'form' : CreateDeckForm(request.POST),
                            'invalidQuantity' :"Commander decks can only have one copy of each card"
                        }
                        return render(request,'collection/create_deck.html',context)


            if form.cleaned_data['mtg_format'] == 'Commander' :
                deck_colors = deck_commander.color
                num_of_nonlands +=1
                current_card = requests.get("https://api.scryfall.com/cards/named?exact=" + deck_commander.name).json()
                if current_card.get("prices").get("usd"):
                    total_cost += float(current_card.get("prices").get("usd"))
                else:
                    total_cost += float(current_card.get("prices").get("usd_foil"))
                tot_cmc += float(deck_commander.cmc)
                if 'B' in deck_colors:
                    num_of_basic_lands  += num_of_swamp
                else:
                    num_of_swamp = 0
                if 'G' in deck_colors:
                    num_of_basic_lands  += num_of_forest
                else:
                    num_of_forest = 0 
                if 'U' in deck_colors:
                    num_of_basic_lands  += num_of_island
                else:
                    num_of_island = 0
                if 'W' in deck_colors:
                    num_of_basic_lands  += num_of_plain
                else:
                    num_of_plain = 0
                if 'R' in deck_colors:
                    num_of_basic_lands  += num_of_mountain
                else:
                    num_of_mountain = 0
            
            else:
                num_of_basic_lands  += num_of_forest 
                num_of_basic_lands  += num_of_island
                num_of_basic_lands  += num_of_mountain
                num_of_basic_lands  += num_of_plain
                num_of_basic_lands  += num_of_swamp
            
            #handles land count, price, cmc 
            for card in deck_list:

                current_is_land = False 
                current_name = card.name
                current_card = requests.get("https://api.scryfall.com/cards/named?exact=" + current_name).json()

                if "Land" in current_card.get('type_line'):
                    num_of_lands_in_list += 1 
                    current_is_land = True 

                    if current_card.get("card_faces") and current_card.get("type_line") != "Land // Land":
                        tot_cmc += current_card.get("cmc")
                        num_of_nonlands +=1

                if current_card.get("colors"):
                    for char in current_card.get("colors"):
                        if deck_colors.find(char) < 0:
                            deck_colors += char


                if current_card.get("prices").get("usd"):
                    total_cost += float(current_card.get("prices").get("usd"))
                else:
                    total_cost += float(current_card.get("prices").get("usd_foil"))

                if current_is_land == False: 
                    tot_cmc += current_card.get("cmc")
                    num_of_nonlands +=1

                time.sleep(.1)

            if num_of_nonlands:
                avg_cmc = tot_cmc/num_of_nonlands
                avg_cmc = float("{:.2f}".format(avg_cmc))
                
            total_Lands = num_of_basic_lands + num_of_lands_in_list
            total_cost = float("{:.2f}".format(total_cost))
            newdeck = deck.objects.create(
                name = form.cleaned_data['name'],
                commander = deck_commander,
                mtg_format = form.cleaned_data['mtg_format'],
                colors = deck_colors,
                Tot_price= total_cost,
                Avg_cmc= avg_cmc,
                Basic_Land_count = num_of_basic_lands,
                Land_count = total_Lands,
                num_of_swamp = num_of_swamp,
                num_of_plain = num_of_plain,
                num_of_forest = num_of_forest,
                num_of_island = num_of_island,
                num_of_mountain = num_of_mountain
            )
            deck_list = deck_list.order_by('cmc')
            
            for card in deck_list: 
                newdeck.cards.add(card.id)
            newdeck
            context={
                "form" : self.form_class(initial=self.initial)
        
            }
            return redirect('/my_decks/')
           

        
        return render(request,'collection/create_deck.html',context)

class DeckAddUpdateView(UpdateView):


    #form_class = CreateDeckForm
    template_name = 'collection/create_deck.html'
    queryset = deck.objects.all()
    fields = ['name','num_of_swamp', 'num_of_plain', 'num_of_forest', 'num_of_island','num_of_mountain','cards']
    def get_form(self,form_class= None):
        
        form = super(DeckAddUpdateView, self).get_form(form_class)
        form_format = super().get_object().mtg_format
        form.fields['name'].widget = forms.TextInput()
        if form_format == 'Standard':
            form.fields["cards"].queryset = card_in_collection.objects.filter(Q(standard_legal = 'legal') & ~Q( id__in =self.get_object().cards.all()))
        if form_format == 'Pioneer':
            form.fields["cards"].queryset = card_in_collection.objects.filter(Q(pioneer_legal = 'legal') & ~Q( id__in =self.get_object().cards.all()))
        if form_format == 'Modern':
            form.fields["cards"].queryset = card_in_collection.objects.filter(Q(modern_legal = 'legal') & ~Q( id__in =self.get_object().cards.all()))
        if form_format == 'Legacy':
            form.fields["cards"].queryset = card_in_collection.objects.filter(Q(legacy_legal = 'legal') & ~Q( id__in =self.get_object().cards.all()))
        if form_format == 'Vintage':
            form.fields["cards"].queryset = card_in_collection.objects.filter(Q(vintage_legal = 'legal') & ~Q( id__in =self.get_object().cards.all()))
        if form_format == 'Pauper':
            form.fields["cards"].queryset = card_in_collection.objects.filter(Q(pauper_legal = 'legal') & ~Q( id__in =self.get_object().cards.all()))
        if form_format == 'Historic':
            form.fields["cards"].queryset = card_in_collection.objects.filter(Q(historic_legal = 'legal') & ~Q( id__in =self.get_object().cards.all()))
        
        if form_format == 'Commander':
            colors = super().get_object().colors
            temp_set = card_in_collection.objects.filter(commander_legal = 'legal')
            color_set = card_in_collection.objects.none()
            for card in temp_set:
                testint = 0
                if card.color:
                    for char in card.color:
                        if colors.find(char) < 0:
                            testint -= 1

                if testint == 0 :
                    color_set |= card_in_collection.objects.filter(pk=card.pk)

            form.fields["cards"].queryset =color_set

        return form
    
    def get_object(self):
        context = super().get_object()
        return context

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        return kwargs

    def form_valid(self,form):

        total_cost = 0 
        num_of_lands_in_list = 0
        num_of_nonlands = 0.0
        num_of_basic_lands = 0
        deck_colors = ''
        tot_cmc = 0

        current_deck = self.get_object()
        current_deck_list = current_deck.cards.all()
        

        
        deck_format = current_deck.mtg_format
        cards_to_be_added = form.cleaned_data["cards"]
        num_of_forest  = form.cleaned_data['num_of_forest']
        num_of_island  = form.cleaned_data['num_of_island']
        num_of_mountain  = form.cleaned_data['num_of_mountain']
        num_of_plain = form.cleaned_data['num_of_plain']
        num_of_swamp  = form.cleaned_data['num_of_swamp']
        

        #checks for correct number of each card in a deck 
        for card in cards_to_be_added:
            num_of_copies = cards_to_be_added.filter(name = card.name).count()
            if current_deck_list.filter(name = card.name): 
                num_of_copies += current_deck_list.filter(name = card.name).count()
            if deck_format =="Commander" and num_of_copies > 1 and card.name not in limit_exceptions:
                context = {
                    'invalidQuantity' : "Commander decks can only have one copy of each card",
                    'form' : self.get_form()
                }
                return render(self.request, 'collection/create_deck.html',context)
            if num_of_copies > 4 and card.name not in limit_exceptions:
                context = {
                    'invalidQuantity' : "A Deck can only have 4 copies of most cards",
                    'form' : self.get_form()
                }
                return render(self.request, 'collection/create_deck.html',context)


        #section handles updating commander price and updating land count for commander decks
        if deck_format == 'Commander':
            deck_commander = current_deck.commander
            deck_colors = deck_commander.color 
            num_of_nonlands +=1
            
            current_card = requests.get("https://api.scryfall.com/cards/named?exact=" + deck_commander.name).json()
            
            if current_card.get("prices").get("usd"):
                total_cost += float(current_card.get("prices").get("usd"))
            else:
                total_cost += float(current_card.get("prices").get("usd_foil"))
            
            tot_cmc += float(deck_commander.cmc)
            
            if 'B' in deck_colors:
                num_of_basic_lands  += num_of_swamp
            else:
                num_of_swamp = 0
            if 'G' in deck_colors:
                num_of_basic_lands  += num_of_forest
            else:
                num_of_forest = 0 
            if 'U' in deck_colors:
                num_of_basic_lands  += num_of_island
            else:
                num_of_island = 0
            if 'W' in deck_colors:
                num_of_basic_lands  += num_of_plain
            else:
                num_of_plain = 0
            if 'R' in deck_colors:
                num_of_basic_lands  += num_of_mountain
            else:
                num_of_mountain = 0
        else:
            num_of_basic_lands  += num_of_forest 
            num_of_basic_lands  += num_of_island
            num_of_basic_lands  += num_of_mountain
            num_of_basic_lands  += num_of_plain
            num_of_basic_lands  += num_of_swamp

        

        # add here 
        if cards_to_be_added:
            for card in cards_to_be_added:
                current_deck.cards.add(card)

        
        for card in current_deck.cards.all():

            current_is_land = False 
            current_name = card.name
            current_card = requests.get("https://api.scryfall.com/cards/named?exact=" + current_name).json()

            if "Land" in current_card.get('type_line'):
                num_of_lands_in_list += 1 
                current_is_land = True 

                if current_card.get("card_faces") and current_card.get("type_line") != "Land // Land":
                    tot_cmc += current_card.get("cmc")
                    num_of_nonlands +=1

            if current_card.get("color_identity") and len(current_deck.colors) != 5:
                for char in current_card.get("color_identity"):
                    if deck_colors.find(char) < 0:
                        deck_colors += char

            if current_card.get("prices").get("usd"):
                total_cost += float(current_card.get("prices").get("usd"))
            else:
                total_cost += float(current_card.get("prices").get("usd_foil"))

            if current_is_land == False: 
                tot_cmc += current_card.get("cmc")
                num_of_nonlands +=1
            time.sleep(.1)
            
        if num_of_nonlands:
            avg_cmc = tot_cmc/num_of_nonlands
            avg_cmc = float("{:.2f}".format(avg_cmc))
                
        total_Lands = num_of_basic_lands + num_of_lands_in_list
        total_cost = float("{:.2f}".format(total_cost))

        current_deck.colors = deck_colors 
        current_deck.Basic_Land_count = num_of_basic_lands
        current_deck.Land_count = total_Lands    
        current_deck.num_of_forest  = num_of_forest  
        current_deck.num_of_island  = num_of_island  
        current_deck.num_of_mountain = num_of_mountain 
        current_deck.num_of_plain  = num_of_plain
        current_deck.num_of_swamp = num_of_swamp
        current_deck.Tot_price = total_cost
        current_deck.Avg_cmc = avg_cmc 

        current_deck.save()




        

        return redirect(self.get_object())
        
    def form_invalid(self,form):
        
        return redirect(self.get_object())

class DeckRemoveUpdateView(UpdateView):
    template_name = 'collection/create_deck.html'
    queryset = deck.objects.all()
    fields = ['name','num_of_swamp', 'num_of_plain', 'num_of_forest', 'num_of_island','num_of_mountain','cards']

    def get_form(self, form_class =None):
        form = super(DeckRemoveUpdateView, self).get_form(form_class)
        form.fields["cards"].queryset = card_in_collection.objects.filter(Q(id__in =self.get_object().cards.all()))
        form.fields['name'].widget = forms.TextInput()
        return form

    def get_object(self):
        context = super().get_object()
        return context
    
    def form_valid(self,form):
        
        total_cost = 0 
        num_of_lands_in_list = 0
        num_of_nonlands = 0.0
        num_of_basic_lands = 0
        deck_colors = ''
        tot_cmc = 0
        current_deck = self.get_object()

        num_of_forest  = form.cleaned_data['num_of_forest']
        num_of_island  = form.cleaned_data['num_of_island']
        num_of_mountain  = form.cleaned_data['num_of_mountain']
        num_of_plain = form.cleaned_data['num_of_plain']
        num_of_swamp  = form.cleaned_data['num_of_swamp']

        cards_to_be_removed = form.cleaned_data["cards"] 
        
        for card in cards_to_be_removed:
            current_deck.cards.remove(card)
        current_deck.save()
        
        if current_deck.mtg_format == 'Commander':
            deck_commander = current_deck.commander
            deck_colors = deck_commander.color 
            num_of_nonlands +=1
            current_card = requests.get("https://api.scryfall.com/cards/named?exact=" + deck_commander.name).json()
            
            if current_card.get("prices").get("usd"):
                    total_cost += float(current_card.get("prices").get("usd"))
            else:
                    total_cost += float(current_card.get("prices").get("usd_foil"))
                
            tot_cmc += float(deck_commander.cmc)
                
            if 'B' in deck_colors:
                num_of_basic_lands  += num_of_swamp
            else:
                num_of_swamp = 0
            if 'G' in deck_colors:
                num_of_basic_lands  += num_of_forest
            else:
                num_of_forest = 0 
            if 'U' in deck_colors:
                num_of_basic_lands  += num_of_island
            else:
                num_of_island = 0
            if 'W' in deck_colors:
                num_of_basic_lands  += num_of_plain
            else:
                num_of_plain = 0
            if 'R' in deck_colors:
                num_of_basic_lands  += num_of_mountain
            else:
                num_of_mountain = 0
        else:
            num_of_basic_lands  += num_of_forest 
            num_of_basic_lands  += num_of_island
            num_of_basic_lands  += num_of_mountain
            num_of_basic_lands  += num_of_plain
            num_of_basic_lands  += num_of_swamp

        
        for card in current_deck.cards.all():

            current_is_land = False 
            current_name = card.name
            current_card = requests.get("https://api.scryfall.com/cards/named?exact=" + current_name).json()

            if "Land" in current_card.get('type_line'):
                num_of_lands_in_list += 1 
                current_is_land = True 

                if current_card.get("card_faces") and current_card.get("type_line") != "Land // Land":
                    tot_cmc += current_card.get("cmc")
                    num_of_nonlands +=1

            if current_card.get("color_identity") and len(current_deck.colors) != 5:
                for char in current_card.get("color_identity"):
                    if deck_colors.find(char) < 0:
                        deck_colors += char

            if current_card.get("prices").get("usd"):
                total_cost += float(current_card.get("prices").get("usd"))
            else:
                total_cost += float(current_card.get("prices").get("usd_foil"))

            if current_is_land == False: 
                tot_cmc += current_card.get("cmc")
                num_of_nonlands +=1
            time.sleep(.1)


        if num_of_nonlands:
            avg_cmc = tot_cmc/num_of_nonlands
            avg_cmc = float("{:.2f}".format(avg_cmc))
                
        total_Lands = num_of_basic_lands + num_of_lands_in_list
        total_cost = float("{:.2f}".format(total_cost))



        current_deck.colors = deck_colors 
        current_deck.Basic_Land_count = num_of_basic_lands
        current_deck.Land_count = total_Lands    
        current_deck.num_of_forest  = num_of_forest  
        current_deck.num_of_island  = num_of_island  
        current_deck.num_of_mountain = num_of_mountain 
        current_deck.num_of_plain  = num_of_plain
        current_deck.num_of_swamp = num_of_swamp
        current_deck.Tot_price = total_cost
        current_deck.Avg_cmc = avg_cmc

        current_deck.save()
    
        return redirect(self.get_object())
        
class DeckDeleteView(generic.DeleteView):
    model = deck
    success_url ="/"

class DeckImportView(generic.FormView):
    model = deck
    form_class = DeckImportForm
    template_name = 'collection/deck_import.html'
    initial = {}

    def get(self, request,*args, **kwargs):
        form = self.form_class(initial=self.initial)
        context = { 
            'form' : form
        }
        
        return render(request,'collection/deck_import.html',context)
    
    def post(self, request,*args, **kwargs):
        print("posted")
        form = DeckImportForm(request.POST)
        context = { 
            'form' : form
        }
       
        
        if form.is_valid():
            print('valid form')
            total_cost = 0 
            num_of_lands_in_list = 0
            num_of_nonlands = 0.0
            num_of_basic_lands = 0
            deck_colors = ''
            tot_cmc = 0

            name = form.cleaned_data['deck_name']
            deck_list = form.cleaned_data['deck_list']
            deck_format = form.cleaned_data['deck_format']
            deck_commander = form.cleaned_data['commander']
            num_of_forest  = form.cleaned_data['num_of_forest']
            num_of_island  = form.cleaned_data['num_of_island']
            num_of_mountain  = form.cleaned_data['num_of_mountain']
            num_of_plain = form.cleaned_data['num_of_plain']
            num_of_swamp  = form.cleaned_data['num_of_swamp']
            
            card_id_list = []
            new_card_ids= []
            invalid_card_list = []
            commander_id = card_in_collection.objects.none()
            
            card_name_list = deck_list.split('\n') 
            num_of_cards = len(card_name_list)
            
            
            #checks for correct count of cards in the deck 
            #checked before new cards are created 
           
            #validating the import list
            if deck_format != "Bulk":
                print('not bulk')
                for i in range(num_of_cards):
                    templist = card_name_list[i].split(' ',1)
                    if len(templist) == 2:
                        print('before dupe line')
                        for k in range(num_of_cards):
                            tempname = card_name_list[k].split(' ',1)
                            if k != i and templist[1] == tempname[1]:
                                context= {
                                'form' : DeckImportForm,
                                'invalidQuantity': "Please do not include the same card on two separate lines"
                            }
                                return render(request, 'collection/deck_import.html',context)
                        print('after dupe line')
                        if deck_format == "Commander" and int(templist[0]) > 1 and templist[1] not in limit_exceptions:
                            
                            context= {
                                'form' : DeckImportForm,
                                'invalidQuantity': "Commander decks can only have one copy of each card"
                            }
                            return render(request, 'collection/deck_import.html',context)
                        print('after commander')
                        if int(templist[0]) > 4 and templist[1] not in limit_exceptions:
                            
                            context= {
                                    'form' : DeckImportForm,
                                    'invalidQuantity': "A Deck can only have 4 copies of most cards"
                                }
                            return render(request, 'collection/deck_import.html',context)
                        print('after deck')
                    if len(templist) != 2: 
                        context= {
                            'form' : DeckImportForm,
                            'format_error': "Import list is formatted incorrectly"
                        }
                        return render(request,'collection/deck_import.html',context)

            print('passed bulk check')
            for i in range(num_of_cards):  
                print("valid form")
                templist = card_name_list[i].split(' ',1)
               
                if len(templist) == 2:
                    num_of_copies = int(templist[0])
                    card_name = templist[1].rstrip() 
                    pot_card = card_in_collection.objects.filter(name__icontains = card_name)
                    invalid_tuple = ()
                    format_legal = True

                    #if all copies of card are already in db
                    if pot_card.count() > 0:
                        pot_card_first = card_in_collection.objects.filter(name__icontains = card_name)[0]
                        if deck_format == 'Standard' and pot_card_first.standard_legal == "not_legal":
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            format_legal = False
                        if deck_format == 'Historic' and pot_card_first.historic_legal == "not_legal":
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            format_legal = False
                        if deck_format == 'Pioneer' and pot_card_first.pioneer_legal == "not_legal":
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            format_legal = False
                        if deck_format == 'Modern' and pot_card_first.modern_legal == "not_legal":
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            format_legal = False
                        if deck_format == 'Legacy' and pot_card_first.legacy_legal == "not_legal":
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            format_legal = False
                        if deck_format == 'Pauper'and pot_card_first.pauper_legal == "not_legal":
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            format_legal = False
                        if deck_format == 'Vintage' and pot_card_first.vintage_legal == "not_legal":
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            format_legal = False
                        if deck_format == 'Commander' and pot_card_first.commander_legal == "not_legal":
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            format_legal = False  
                        
                        #add an invalid card
                        if invalid_tuple:
                            invalid_card_list.append(invalid_tuple)
                        
                        if format_legal:
                            if pot_card.count() >= num_of_copies: 
                                for i in range(num_of_copies):
                                    new_card = card_in_collection.objects.filter(name__icontains = card_name)[i]
                                    card_id_list.append(new_card.pk)

                            # handles adding cards to the db         
                            if pot_card.count() < num_of_copies:
                                
                                #creates copies of a preexisting card
                                if pot_card.count() > 0: 
                                    copies_to_be_added = num_of_copies - pot_card.count()
                                    for i in range(copies_to_be_added):
                                        new_card = card_in_collection.objects.filter(name = card_name)[0]
                                        new_card.pk = None 
                                        new_card.save()
                                        new_card_ids.append(new_card.pk)
                                        card_id_list.append(new_card.pk)
                                        
                        
                        #adding cards from api
                    else:
                        card_to_be_added = requests.get("https://api.scryfall.com/cards/named?exact=" + card_name).json()
                        time.sleep(.1)
                        if card_to_be_added.get("object")== "card":
                            if card_to_be_added.get("legalities").get(deck_format.lower()) == "not_legal":
                                
                                format_legal = False
                                invalid_tuple = (templist[0],templist[1].rstrip())
                                invalid_card_list.append(invalid_tuple)
                            if format_legal:
                                #add card to db 
                                #then and add first pk id to list 
                                #then check if num of copies >1
                                #make copies if so  
                                if card_to_be_added.get("layout")  == 'modal_dfc' or card_to_be_added.get('layout') == "transform" :
                                    front_face = card_to_be_added.get("card_faces")[0]
                                    back_face = card_to_be_added.get("card_faces")[1]
                                    new_card = card_in_collection(
                                        name = card_to_be_added.get('name'),
                                        is_Flip = True,
                                        back_side_card_name = back_face.get("name"),        
                                        mana_cost = card_to_be_added.get("mana_cost"),
                                        type_line = card_to_be_added.get("type_line"),
                                        cmc = card_to_be_added.get("cmc"),
                                        image_url = front_face.get("image_uris").get("border_crop"),
                                        back_side_img_url = back_face.get("image_uris").get("border_crop"),
                                        card_description = front_face.get("oracle_text") + "//" + back_face.get("oracle_text"),
                                        flavor_text = front_face.get("flavor_text"),
                                        color = card_to_be_added.get("color_identity"),
                                        standard_legal = card_to_be_added.get("legalities").get("standard"),
                                        historic_legal = card_to_be_added.get("legalities").get("historic"),
                                        pioneer_legal = card_to_be_added.get("legalities").get("pioneer"),
                                        modern_legal = card_to_be_added.get("legalities").get("modern"),
                                        legacy_legal = card_to_be_added.get("legalities").get("legacy"),
                                        pauper_legal = card_to_be_added.get("legalities").get("pauper"),
                                        vintage_legal = card_to_be_added.get("legalities").get("vintage"),
                                        commander_legal = card_to_be_added.get("legalities").get("commander"),
                                    )
                                    new_card.save()
                                    new_card_ids.append(new_card.pk)
                                    card_id_list.append(new_card.pk)
                                
                                if card_to_be_added.get("layout") == "split" or card_to_be_added.get("layout") == "flip" :
                                    front_face = card_to_be_added.get("card_faces")[0]
                                    back_face = card_to_be_added.get("card_faces")[1]
                                    new_card = card_in_collection(
                                        name = card_to_be_added.get('name'),
                                        is_Flip = True,
                                        back_side_card_name = back_face.get("name"),        
                                        mana_cost = card_to_be_added.get("mana_cost"),
                                        type_line = card_to_be_added.get("type_line"),
                                        cmc = card_to_be_added.get("cmc"),
                                        image_url = card_to_be_added.get("image_uris").get("border_crop"),
                                        back_side_img_url = '',
                                        card_description = front_face.get("oracle_text") + "//" + back_face.get("oracle_text"),
                                        flavor_text = front_face.get("flavor_text"),
                                        color = card_to_be_added.get("color_identity"),
                                        standard_legal = card_to_be_added.get("legalities").get("standard"),
                                        historic_legal = card_to_be_added.get("legalities").get("historic"),
                                        pioneer_legal = card_to_be_added.get("legalities").get("pioneer"),
                                        modern_legal = card_to_be_added.get("legalities").get("modern"),
                                        legacy_legal = card_to_be_added.get("legalities").get("legacy"),
                                        pauper_legal = card_to_be_added.get("legalities").get("pauper"),
                                        vintage_legal = card_to_be_added.get("legalities").get("vintage"),
                                        commander_legal = card_to_be_added.get("legalities").get("commander"),                                    
                                    )
                                    new_card.save()
                                    new_card_ids.append(new_card.pk)
                                    card_id_list.append(new_card.pk)
                            
                                else:
                                    new_card = card_in_collection(
                                        name = card_to_be_added.get('name'),
                                        is_Flip = False,
                                        back_side_card_name = '',    
                                        mana_cost = card_to_be_added.get("mana_cost"),
                                        type_line = card_to_be_added.get("type_line"),
                                        cmc = card_to_be_added.get("cmc"),
                                        image_url = card_to_be_added.get("image_uris").get("border_crop"),
                                        back_side_img_url = '',
                                        card_description = card_to_be_added.get("oracle_text"),
                                        flavor_text = card_to_be_added.get("flavor_text"),
                                        color = card_to_be_added.get("color_identity"),
                                        standard_legal = card_to_be_added.get("legalities").get("standard"),
                                        historic_legal = card_to_be_added.get("legalities").get("historic"),
                                        pioneer_legal = card_to_be_added.get("legalities").get("pioneer"),
                                        modern_legal = card_to_be_added.get("legalities").get("modern"),
                                        legacy_legal = card_to_be_added.get("legalities").get("legacy"),
                                        pauper_legal = card_to_be_added.get("legalities").get("pauper"),
                                        vintage_legal = card_to_be_added.get("legalities").get("vintage"),
                                        commander_legal = card_to_be_added.get("legalities").get("commander"),
                                    )
                                    new_card.save()
                                    new_card_ids.append(new_card.pk)
                                    card_id_list.append(new_card.pk)
                        else:
                            invalid_tuple = (templist[0],templist[1].rstrip())
                            invalid_card_list.append(invalid_tuple)
                else: 
                    context= {
                        'form' : DeckImportForm,
                        'format_error': "Import list is formatted incorrectly"
                    }
                    return render(request,'collection/deck_import.html',context)

            #pulls data on the commander card as well as creating the commander if needed
            if deck_format == "Commander":
                
                commander = requests.get("https://api.scryfall.com/cards/named?exact=" + deck_commander).json()
                
                if commander.get('object') =='card' :
                    if "Legendary Creature" in commander.get("type_line") or "can be your commander" in commander.get("oracle_text"):
                        deck_colors = commander.get("color_identity")
                        tot_cmc += float(commander.get('cmc'))
                        num_of_nonlands +=1
                        if commander.get("prices").get("usd"):
                            total_cost += float(commander.get("prices").get("usd"))
                        else:
                            total_cost += float(commander.get("prices").get("usd_foil"))

                        if card_in_collection.objects.filter(name__icontains = deck_commander): 
                            
                            commander_id = card_in_collection.objects.filter(name = commander.get("name"))[0]
                        #create chunk
                        else:
                            if commander.get("layout")  == 'modal_dfc' or commander.get('layout') == "transform" :
                                front_face = commander.get("card_faces")[0]
                                back_face = commander.get("card_faces")[1]
                                new_card = card_in_collection(
                                    name = front_face.get('name'),
                                    is_Flip = True,
                                    back_side_card_name = back_face.get("name"),        
                                    mana_cost = commander.get("mana_cost"),
                                    type_line = commander.get("type_line"),
                                    cmc = commander.get("cmc"),
                                    image_url = front_face.get("image_uris").get("border_crop"),
                                    back_side_img_url = back_face.get("image_uris").get("border_crop"),
                                    card_description = front_face.get("oracle_text"),
                                    flavor_text = front_face.get("flavor_text"),
                                    color = commander.get("color_identity"),
                                    standard_legal = commander.get("legalities").get("standard"),
                                    historic_legal = commander.get("legalities").get("historic"),
                                    pioneer_legal = commander.get("legalities").get("pioneer"),
                                    modern_legal = commander.get("legalities").get("modern"),
                                    legacy_legal = commander.get("legalities").get("legacy"),
                                    pauper_legal = commander.get("legalities").get("pauper"),
                                    vintage_legal = commander.get("legalities").get("vintage"),
                                    commander_legal = commander.get("legalities").get("commander"),
                                    )
                                new_card.save()
                                new_card_ids.append(new_card.pk)
                                commander_id = card_in_collection.objects.get(pk = new_card.pk)

                            if card_to_be_added.get("layout") == "split" or card_to_be_added.get("layout") == "flip":
                                front_face = card_to_be_added.get("card_faces")[0]
                                back_face = card_to_be_added.get("card_faces")[1]
                                new_card = card_in_collection(
                                    name = card_to_be_added.get('name'),
                                    is_Flip = True,
                                    back_side_card_name = back_face.get("name"),        
                                    mana_cost = card_to_be_added.get("mana_cost"),
                                    type_line = card_to_be_added.get("type_line"),
                                    cmc = card_to_be_added.get("cmc"),
                                    image_url = card_to_be_added.get("image_uris").get("border_crop"),
                                    back_side_img_url = '',
                                    card_description = front_face.get("oracle_text") + "//" + back_face.get("oracle_text"),
                                    flavor_text = front_face.get("flavor_text"),
                                    color = card_to_be_added.get("color_identity"),
                                    standard_legal = card_to_be_added.get("legalities").get("standard"),
                                    historic_legal = card_to_be_added.get("legalities").get("historic"),
                                    pioneer_legal = card_to_be_added.get("legalities").get("pioneer"),
                                    modern_legal = card_to_be_added.get("legalities").get("modern"),
                                    legacy_legal = card_to_be_added.get("legalities").get("legacy"),
                                    pauper_legal = card_to_be_added.get("legalities").get("pauper"),
                                    vintage_legal = card_to_be_added.get("legalities").get("vintage"),
                                    commander_legal = card_to_be_added.get("legalities").get("commander"),
                                )
                                new_card.save()
                                new_card_ids.append(new_card.pk)
                                commander_id = card_in_collection.objects.get(pk = new_card.pk)

                            else:
                                new_card = card_in_collection(
                                    name = commander.get('name'),
                                    is_Flip = False,
                                    back_side_card_name = '',    
                                    mana_cost = commander.get("mana_cost"),
                                    type_line = commander.get("type_line"),
                                    cmc = commander.get("cmc"),
                                    image_url = commander.get("image_uris").get("border_crop"),
                                    back_side_img_url = '',
                                    card_description = commander.get("oracle_text"),
                                    flavor_text = commander.get("flavor_text"),
                                    color = commander.get("color_identity"),
                                    standard_legal = commander.get("legalities").get("standard"),
                                    historic_legal = commander.get("legalities").get("historic"),
                                    pioneer_legal = commander.get("legalities").get("pioneer"),
                                    modern_legal = commander.get("legalities").get("modern"),
                                    legacy_legal = commander.get("legalities").get("legacy"),
                                    pauper_legal = commander.get("legalities").get("pauper"),
                                    vintage_legal = commander.get("legalities").get("vintage"),
                                    commander_legal = commander.get("legalities").get("commander"),
                                )
                                new_card.save()
                                new_card_ids.append(new_card.pk)
                                commander_id = card_in_collection.objects.get(pk = new_card.pk)

                        
                        
                        #check colors 
                        #check cards in deck for correct colors 
                        for id_ in card_id_list:
                            color_correct = True 
                            card = card_in_collection.objects.get(pk = id_) 
                            if card.color:
                                for char in card.color:
                                    if commander_id.color.find(char) < 0:
                                        color_correct = False
                            
                            if color_correct == False:
                                invalid_card_list.append(card.name)     
                    else:
                        invalid_card_list.append(deck_commander)

                if commander.get('object') =='error' :
                    invalid_tuple = ('Commander',deck_commander) 
                    invalid_card_list.append(invalid_tuple)

        
            #remove cards created during failed import
            if len(invalid_card_list) > 0:
                print(invalid_card_list)
                if new_card_ids:
                    for i in new_card_ids:
                       
                        card_in_collection.objects.get(pk=i).delete()
                
                context ={
                    'form' : DeckImportForm,
                    "invalid_cards": invalid_card_list

                }
                return render(request, 'collection/deck_import.html',context)
            
            else:
                if deck_format == "Bulk":
                    return redirect('/')
                #handles basic lands in deck
                if deck_format == "Commander":
                    if 'B' in deck_colors:
                        num_of_basic_lands  += num_of_swamp
                    else:
                        num_of_swamp = 0
                    if 'G' in deck_colors:
                        num_of_basic_lands  += num_of_forest
                    else:
                        num_of_forest = 0 
                    if 'U' in deck_colors:
                        num_of_basic_lands  += num_of_island
                    else:
                        num_of_island = 0
                    if 'W' in deck_colors:
                        num_of_basic_lands  += num_of_plain
                    else:
                        num_of_plain = 0
                    if 'R' in deck_colors:
                        num_of_basic_lands  += num_of_mountain
                    else:
                        num_of_mountain = 0
                else:
                    num_of_basic_lands  += num_of_forest 
                    num_of_basic_lands  += num_of_island
                    num_of_basic_lands  += num_of_mountain
                    num_of_basic_lands  += num_of_plain
                    num_of_basic_lands  += num_of_swamp

                #block for generating deck variables
                for card in card_id_list:
                    current_is_land = False 
                    current_card = card_in_collection.objects.get(id=card)
                    card_from_scryfall = requests.get("https://api.scryfall.com/cards/named?exact=" + current_card.name).json()

                    if "Land" in card_from_scryfall.get('type_line'):
                        num_of_lands_in_list += 1 
                        current_is_land = True 

                    if card_from_scryfall.get("card_faces") and card_from_scryfall.get("type_line") != "Land // Land":
                        tot_cmc += card_from_scryfall.get("cmc")
                        num_of_nonlands +=1

                    if card_from_scryfall.get("color_identity"):
                        for char in card_from_scryfall.get("color_identity"):
                            if char not in deck_colors:
                                deck_colors +=char


                    if card_from_scryfall.get("prices").get("usd"):
                        total_cost += float(card_from_scryfall.get("prices").get("usd"))
                    else:
                        total_cost += float(card_from_scryfall.get("prices").get("usd_foil"))

                    if current_is_land == False: 
                        tot_cmc += card_from_scryfall.get("cmc")
                        num_of_nonlands +=1

                    time.sleep(.1)
                if num_of_nonlands:
                    avg_cmc = tot_cmc/num_of_nonlands
                    avg_cmc = float("{:.2f}".format(avg_cmc))
            
                total_Lands = num_of_basic_lands + num_of_lands_in_list
                total_cost = float("{:.2f}".format(total_cost))
                #finalizing the deck, creating the object and adding the card list to it 
                newdeck = deck.objects.create(
                    name = form.cleaned_data['deck_name'],
                    commander = commander_id or None,
                    mtg_format = form.cleaned_data['deck_format'],
                    colors = deck_colors,
                    Tot_price= total_cost,
                    Avg_cmc= avg_cmc,
                    Basic_Land_count = num_of_basic_lands,
                    Land_count = total_Lands,
                    num_of_swamp = num_of_swamp,
                    num_of_plain = num_of_plain,
                    num_of_forest = num_of_forest,
                    num_of_island = num_of_island,
                    num_of_mountain = num_of_mountain
                )
                for card in card_id_list: 
                    newdeck.cards.add(card_in_collection.objects.get(pk=card))

        return redirect(newdeck)