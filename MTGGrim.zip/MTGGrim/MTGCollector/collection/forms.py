from django import forms
from .models import card_in_collection,deck 
from string import Template
from django.utils.safestring import mark_safe

card_types = [ 

  ('','Choose a Type'), 
  ('Artifact','Artifact'), 
  ('Conspiracy','Conspiracy'), 
  ('Creature','Creature'), 
  ('Enchantment','Enchantment'),
  ('Instant','Instant'),
  ('Land','Land'),
  ('Planeswalker','Planeswalker')
  ]
format_choices = [
  ('','Choose a Format'), 
  ('Standard','Standard'),
  ('Historic','Historic'),
  ('Pioneer','Pioneer'),
  ('Modern','Modern'),
  ('Legacy','Legacy'),
  ('Pauper','Pauper'),
  ('Vintage','Vintage'),
  ('Commander','Commander')
]
Sort_by = [
('','Sort by'),
('Name_ASC','Name'),
('Name_DESC','Name'),
('Mana Cost_ASC','Mana Cost'),
('Mana Cost_DESC','Mana Cost'),


]
import_choices = [
  ('','Choose a Format'),
  ('Standard','Standard'),
  ('Historic','Historic'),
  ('Pioneer','Pioneer'),
  ('Modern','Modern'),
  ('Legacy','Legacy'),
  ('Pauper','Pauper'),
  ('Vintage','Vintage'),
  ('Commander','Commander'),
  ('Bulk', "Bulk Add to Your Collection") 
]

viable_commanders = card_in_collection.objects.filter(card_description__icontains = "can be your commander") | card_in_collection.objects.filter(type_line__icontains = "Legendary Creature")



class CardSearchForm(forms.Form):
  card_name = forms.CharField(
                    required = False,
                    label='Search by Card Name',
                    widget=forms.TextInput(attrs={'placeholder': 'search here!'})
                  )
  cmc = forms.IntegerField(required = False,
                    label='Search by Converted Mana Cost',
                    )
  #Type_line
  Card_Type = forms.CharField(required = False,
                    widget=forms.Select(choices=card_types)
                  )
  Color = forms.CharField(required = False)
  #overidding clean function in order to validate one but not one specific required 
  def clean(self):
    card_name = self.cleaned_data.get('card_name')
    cmc = self.cleaned_data.get('cmc')
    Card_Type = self.cleaned_data.get('Card_Type')
    Color = self.cleaned_data.get('Color')
    if not card_name and not cmc and not Card_Type and not Color :
      raise forms.ValidationError('One of the fields is required')
    return self.cleaned_data


class CreateDeckForm(forms.ModelForm):

  class Meta:

    model = deck 
    fields = ('name','mtg_format','commander','num_of_swamp', 'num_of_plain', 'num_of_forest', 'num_of_island','num_of_mountain','cards')
      
    queryset = {
      'cards' : card_in_collection.objects.all()
    }

    widgets ={
      'name' : forms.TextInput,
      'cards' :  forms.CheckboxSelectMultiple,
      'mtg_format' : forms.Select(choices=format_choices),
      
      
    }
    labels ={
      'num_of_swamp' : 'Number of Swamps',
      'num_of_plain' : "Number of Plains", 
      'num_of_forest' : "Number of Forests", 
      'num_of_island' : 'Number of Islands',
      'num_of_mountain' : "Number of Mountains"
    }
  def clean(self):
    cleaned_data=super(CreateDeckForm,self).clean()
    mtg_format = self.cleaned_data.get("mtg_format")
    Commander = self.cleaned_data.get("commander")
    deck_list = self.cleaned_data.get("cards")
    
    #check for commander decks have a commander 
    if mtg_format == 'Commander' and not Commander:
      raise forms.ValidationError('A Commander Deck requires a Commander!')
    
    #check for commander color restrictions 
    if mtg_format =='Commander' and deck_list:   
      for card in deck_list:
        if card.color:
          for char in card.color:
            if Commander.color.find(char) < 0:
              raise forms.ValidationError("Cards must match the commanders colors")
    
    #check legalities 
    if deck_list:
      invalid_card_list =[] 
      for card in deck_list:
        if mtg_format == 'Standard' and card.standard_legal == "not_legal":
          invalid_card_list.append(card.name) 
          
        if mtg_format == 'Historic' and card.historic_legal == "not_legal":
          invalid_card_list.append(card.name)
        if mtg_format == 'Pioneer' and card.pioneer_legal == "not_legal":
          invalid_card_list.append(card.name)
        if mtg_format == 'Modern' and card.modern_legal == "not_legal":
          invalid_card_list.append(card.name)
        if mtg_format == 'Legacy' and card.legacy_legal == "not_legal":
          invalid_card_list.append(card.name)
        if mtg_format == 'Pauper'and card.pauper_legal == "not_legal":
          invalid_card_list.append(card.name)
        if mtg_format == 'Vintage' and card.vintage_legal == "not_legal":
          invalid_card_list.append(card.name)
        if mtg_format == 'Commander' and card.commander_legal == "not_legal":
          invalid_card_list.append(card.name)
      if invalid_card_list:
        raise forms.ValidationError("The following cards arent legal in the given format" + str(invalid_card_list))    
    return self.cleaned_data
      

    
    
    

class DeckImportForm(forms.Form):

  deck_name = forms.CharField()
  deck_format = forms.CharField(widget = forms.Select(choices=import_choices))
  commander = forms.CharField(required = False)
  
  num_of_swamp = forms.IntegerField(label="Number of Swamps",required = False,initial=0,min_value=0)
  num_of_plain = forms.IntegerField(label="Number of Plains",required = False,initial=0,min_value=0)
  num_of_forest = forms.IntegerField(label="Number of Forests",required = False,initial=0,min_value=0)
  num_of_island = forms.IntegerField(label="Number of Islands",required = False,initial=0,min_value=0)
  num_of_mountain = forms.IntegerField(label="Number of Mountains",required = False,initial=0,min_value=0)
  deck_list = forms.CharField(widget=forms.Textarea)
  def clean(self):
    cleaned_data=super(DeckImportForm,self).clean()
    deck_format = self.cleaned_data.get("deck_format")
    commander = self.cleaned_data.get("commander")

    if deck_format == "Commander" and not commander: 
      raise forms.ValidationError('A Commander Deck requires a commander')