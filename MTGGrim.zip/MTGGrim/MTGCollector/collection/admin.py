from django.contrib import admin
from .models import card_in_collection,deck

# Register your models here.
admin.site.register(card_in_collection)
admin.site.register(deck)