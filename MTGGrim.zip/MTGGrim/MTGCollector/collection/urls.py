from django.urls import path
from django.contrib import admin
from django.views.decorators.csrf import csrf_exempt
from . import views
from .views import (
    CollectionView,
    CardDetailView,
    SearchView,
    add_card_view,
    DeckCreateView,
    CardDeleteView,
    DeckListView,
    DeckDetailView,
    DeckAddUpdateView,
    DeckRemoveUpdateView,
    DeckImportView,
    DeckDeleteView,
    SearchCollectionView
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('search/', csrf_exempt(SearchCollectionView.as_view()), name='search_results'),
    path('', CollectionView.as_view(), name='collection-home'),
    path('deck/<int:pk>/',DeckDetailView.as_view(), name ='deck-detail'),
    path('my_decks/', DeckListView.as_view(), name= 'deck-list'),
    path('deck/<int:pk>/update',DeckAddUpdateView.as_view(),name ='deck-update'),
    path('deck/<int:pk>/remove',DeckRemoveUpdateView.as_view(),name ='deck-remove'),
    path('deck/<pk>/delete',DeckDeleteView.as_view()),
    path('deck_import',DeckImportView.as_view(),name ='deck-import'),
    path('add/', SearchView.as_view(), name='search'),
    path('add_card_confirm/',add_card_view.as_view(), name ="add_card"),
    path('card/<pk>/delete', CardDeleteView.as_view(), name='delete_card'),
    path('card/<int:pk>/', CardDetailView.as_view(), name='card-detail'),
    path('create_deck/',DeckCreateView.as_view(), name ='deck_list' )
]
